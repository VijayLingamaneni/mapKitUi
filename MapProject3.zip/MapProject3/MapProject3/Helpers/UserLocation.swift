//
//  UserLocation.swift
//  MapProject3
//
//  Created by VIJAY LINGAMANENI on 5/18/21.

import Foundation
import CoreLocation


class UserLocation: NSObject , CLLocationManagerDelegate {
    
    static let shared : UserLocation = UserLocation()
    var locationManager     : CLLocationManager = CLLocationManager()
    var location : CLLocation = CLLocation()
    
    
    
    //---------------------------------------------------------------------
    
    deinit {
        
    }
    
    override init() {
        super.init()
        self.locationSetup()
    }
    
    
    
    //MARK: - Current Lat Long
    
    //TODO: To get location permission just call this method
    func locationSetup() {
//        locationManager = CLLocationManager()
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    //TODO: To get permission is allowed or declined
    func checkStatus() -> CLAuthorizationStatus{
        return CLLocationManager.authorizationStatus()
    }
    
    //TODO: To get user's current location
    func getUserLocation() -> CLLocation {
        if location.coordinate.longitude == 0.0 {
            return CLLocation(latitude: 0.0, longitude: 0.0)
        }
        
        return location
    }
    
    //MARK: Delegate method
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // store user's location
        location = locations[0]

    }

    
    private func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        
        switch status {
            
        case .denied:
            print("location Permission denied")
            break
        case .notDetermined:
            print("unknown")
            break
            
        default:
            print("\(location.coordinate)")
            break
        }
    }
    
}



