//
//  CommonExtensions.swift
//  MapProject3
//
//  Created by VIJAY LINGAMANENI on 5/18/21.

import Foundation
import CoreLocation
import MapKit


extension MKMapView{
    
    
    func addMarker(_ markerTitle:String,_ currentDistance:String,_ markerLocation:CLLocationCoordinate2D) -> MKPointAnnotation{
        let pin = MKPointAnnotation()
        pin.subtitle = "Distance is \(currentDistance) KMs"
        pin.title = "Marker \(markerTitle)"
        pin.coordinate = markerLocation
        self.addAnnotation(pin)
        return pin
    }
    
    func clearOverlays(){
        self.removeOverlays(self.overlays)
    }
    
    func drawPolygon(_ coordinates:[CLLocationCoordinate2D]){
        self.removeOverlays(self.overlays)
        let overlay = MKPolygon(coordinates: coordinates, count: coordinates.count)
        self.addOverlay(overlay)
    }
    
    func boundTo(_ polygon : MKPolygon){
        self.setRegion(MKCoordinateRegion(polygon.boundingMapRect), animated: true)
    }
    
    func drawRouteFrom(_ source:CLLocationCoordinate2D,_ destintation:CLLocationCoordinate2D){
        let sourcePlacemark = MKPlacemark(coordinate: source)
        let destinationPlacemark = MKPlacemark(coordinate: destintation)
        //
        let sourceItem = MKMapItem(placemark: sourcePlacemark)
        let destinationItem = MKMapItem(placemark: destinationPlacemark)
        
        let reqest = MKDirections.Request()
        reqest.source = sourceItem
        reqest.destination = destinationItem
        reqest.transportType = .walking
        
        let direction = MKDirections(request: reqest)
        direction.calculate { (response, error) in
            guard let res = response else{
                if let err = error{
                    print("Error: \(err)")
                }
                return
            }
            if let route = res.routes.first{
                self.addOverlay(route.polyline, level: .aboveRoads)
            }
        }
    }
    
}


extension CLLocationCoordinate2D{
    
    func equalTo(_ location:CLLocationCoordinate2D) -> Bool{
        return self.latitude == location.latitude && self.longitude == location.longitude
    }
    
    func distanceFrom(_ location:CLLocationCoordinate2D) -> Double{
        return CLLocation(latitude: self.latitude, longitude: self.longitude).distance(from: CLLocation(latitude: location.latitude, longitude: location.longitude))
    }
    
}


extension Double{
    
    var strDistance  : String{
        let distance = self / 100
        return String(format: "%.2f", distance)
    }
    
}
