//
//  AppDelegate.swift
//  MapProject3
//
//  Created by VIJAY LINGAMANENI on 5/18/21.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        UserLocation.shared.locationSetup()
        return true
    }

   

}

