//
//  InitialVC.swift
//  MapProject3
//
//  Created by VIJAY LINGAMANENI on 5/18/21.

import UIKit

class InitialVC: UIViewController {

    //MARK:- Outlets
    
    //MARK:- Class Variables
    
    //MARK:- Custom Methods
    
    func setUp(){
        
    }
    
    //MARK:- Click Events
    
    @IBAction func btnStartTapped(_ sender : UIButton){
        let objVC = self.storyboard?.instantiateViewController(withIdentifier: "MapRouteVC") as! MapRouteVC
        self.navigationController?.pushViewController(objVC, animated: true)
    }
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
    }

}
