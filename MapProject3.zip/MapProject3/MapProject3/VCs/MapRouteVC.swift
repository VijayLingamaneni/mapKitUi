//
//  MapRouteVC.swift
//  MapProject3
//
//  Created by VIJAY LINGAMANENI on 08-05-2021
//

import UIKit
import MapKit

class MapRouteVC: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var map : MKMapView!
    @IBOutlet weak var btnRoute : UIButton!
    
    //MARK:- Class Variables
    
    let distanceRange : Double = 120
    var pinA : MKPointAnnotation!
    var pinB : MKPointAnnotation!
    var pinC : MKPointAnnotation!
    
    //MARK:- Custom Methods
    
    func setUp(){
        self.removeRouteButton()
        //
        map.delegate = self
        //
        addLongpressGestureOnMap()
    }
    
    func addLongpressGestureOnMap(){
        let longPressGest = UILongPressGestureRecognizer(target: self, action: #selector(longpressMap(_:)))
        longPressGest.minimumPressDuration = 0.3
        map.addGestureRecognizer(longPressGest)
    }
    
    func focusOnUserLocation(){
        let region  = MKCoordinateRegion(center: UserLocation.shared.getUserLocation().coordinate, latitudinalMeters: 450, longitudinalMeters: 700)
        self.map.setRegion(region, animated: true)
    }
    
    func addRouteButton(){
        self.btnRoute.isHidden = false
        
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
            self.btnRoute.alpha = 1
            self.btnRoute.transform = .identity
        }, completion: nil)
    }
    
    func removeRouteButton(){
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
              self.btnRoute.alpha = 0
              self.btnRoute.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        }) { (_) in
            self.btnRoute.isHidden = true
        }

    }
    
    func clearMap(){
        self.pinA = nil
        self.pinB = nil
        self.pinC = nil
        self.map.clearOverlays()
        let annotations = self.map.annotations
        self.map.removeAnnotations(annotations)
    }
    
    //MARK:- Click Events
    
    @IBAction func btnRouteTapped(_ sender : UIButton){
        self.map.clearOverlays()
        self.map.drawRouteFrom(self.pinA.coordinate, self.pinB.coordinate)
        self.map.drawRouteFrom(self.pinB.coordinate, self.pinC.coordinate)
        self.map.drawRouteFrom(self.pinC.coordinate, self.pinA.coordinate)
        self.removeRouteButton()
    }
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.focusOnUserLocation()
    }

}

//MARK:- Longpress on map
extension MapRouteVC {
    
    @objc func longpressMap(_ gesture : UILongPressGestureRecognizer){
        if gesture.state != .began{
            return
        }
        
        let pointInMap:CGPoint = gesture.location(in: self.map)
        let location:CLLocationCoordinate2D =
            self.map.convert(pointInMap, toCoordinateFrom: self.map)
        
        let difference = location.distanceFrom(UserLocation.shared.getUserLocation().coordinate)
        
        checkIfLocationIsNearby(location)
        
        if self.pinA != nil && self.pinB != nil && self.pinC != nil{
            self.clearMap()
            self.removeRouteButton()
        }
        
        if self.pinA == nil{
            self.pinA = self.map.addMarker("A", difference.strDistance, location)
        }else if self.pinB == nil{
            self.pinB = self.map.addMarker("B", difference.strDistance, location)
        }else if self.pinC == nil{
            self.pinC = self.map.addMarker("C", difference.strDistance, location)
        }
        
        self.drawTriangleIfNeeded()
    }
    
    func drawTriangleIfNeeded(){
        if let a = pinA, let b = pinB, let c = pinC{
            let coordinatesArray = [a.coordinate,b.coordinate,c.coordinate]
            self.map.drawPolygon(coordinatesArray)
            self.addRouteButton()
        }
    }
    
    func checkIfLocationIsNearby(_ location : CLLocationCoordinate2D){
        if let tempMarker  = self.pinA{
            let markerDiff = location.distanceFrom(tempMarker.coordinate)
            if tempMarker.coordinate.equalTo(location) || markerDiff <= distanceRange{
                self.map.removeAnnotation(tempMarker)
                self.pinA = nil
                self.removeRouteButton()
                self.map.clearOverlays()
                return
            }
        }
        
        if let tempMarker  = self.pinB{
            let markerDiff = location.distanceFrom(tempMarker.coordinate)
            if tempMarker.coordinate.equalTo(location) || markerDiff <= distanceRange{
                self.map.removeAnnotation(tempMarker)
                self.pinB = nil
                self.removeRouteButton()
                self.map.clearOverlays()
                return
            }
        }
        
        if let tempMarker  = self.pinC{
            let markerDiff = location.distanceFrom(tempMarker.coordinate)
            if tempMarker.coordinate.equalTo(location) || markerDiff <= distanceRange{
                self.map.removeAnnotation(tempMarker)
                self.pinC = nil
                self.removeRouteButton()
                self.map.clearOverlays()
                return
            }
        }
    }
    
}


//MARK:- Map Delegate
extension MapRouteVC : MKMapViewDelegate{
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polygon = overlay as? MKPolygon{
            let rendererForPolygon = MKPolygonRenderer(polygon: polygon)
            rendererForPolygon.fillColor = UIColor.red.withAlphaComponent(0.50)
            rendererForPolygon.strokeColor = UIColor.green
            rendererForPolygon.lineWidth = 3.8
            self.map.boundTo(polygon)
            return rendererForPolygon
        }else if let polyLine = overlay as?  MKPolyline{
            let rendererForPolyline = MKPolylineRenderer(polyline: polyLine)
            rendererForPolyline.strokeColor = UIColor.green
            rendererForPolyline.lineWidth = 3.8
            return rendererForPolyline
        }
        return MKOverlayRenderer()
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
     
        var pinView = map.dequeueReusableAnnotationView(withIdentifier: "MarkerPin") as? MKPinAnnotationView
        if pinView != nil {
            pinView?.annotation = annotation
        } else {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "MarkerPin")
            pinView?.canShowCallout = true
            pinView?.rightCalloutAccessoryView = UIButton(type: .infoDark)
        }
        
        return pinView
    }
    
}
